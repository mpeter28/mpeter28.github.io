# The Thirty One Lieutenants of Sorcerer Bedsui #

"Chaos blankets the world. From his tower in the southern marches, the illusionist Bedsui manipulates the minds of many great Kings and Emperors, sowing war and discord. But soon the madness ends! Steeling their resolve, a band of adventurers prepares to storm the tower and defeat the sorcerer. However, between them and their goal await Bedsui's many servants..."

T31LoSB is a turn based, squad combat game with many of the boilerplate roguelike elements (fantasy setting, ASCII graphics, kill monsters and collect loot...). What distinguishes T31LoSB is the combat system, which dispenses with the usual 'one space per turn movement' and 'melee attacks are all to adjacent squares'. I'm hoping to use T31LoSB as a prototype before using the combat system for a larger, more ambitious game. Feedback is welcome!

## Copyright ##

Copyright 2017 Marcie Peters, antumbrastation.com

## Running the Game ##

T31LoSB requires the Java 8 runtime environment. Run the following command from the command line to play the game

    java -jar bedsui.jar

## Managing Window Size ##

Ctrl + and Ctrl - can be used to increase and decrease the size of the game window to suit your monitor.

## Combat Mechanics ##

All combatants, monsters and player characters, move about the board like tafl pieces (or the rook from chess), only stopping when blocked by a wall, unit, or wandering into an enemy's melee range.

In most roguelikes, the melee range for units are the eight immediately adjacent squares. In T31LoSB different weapons provide different melee ranges specific to the weapon type. The longsword has a different range than the poleaxe

Longsword:

    ..X..
    .X.X.
    X.@.X
    .X.X.
    ..X..

Poleaxe:

    ..X..
    ..X..
    XX@XX
    ..X..
    ..X..

and both are distinct from the Billhook:

    X...X
    .X.X.
    ..@..
    .X.X.
    X...X

The different weapon threat ranges have names. The poleaxe, for example, is a stabing and smashing weapon. The different types are stab weapons,

    .....
    ..X..
    .X@X.
    ..X..
    .....

slash weapons,

    .....
    .X.X.
    ..@..
    .X.X.
    .....

smash weapons,

    ..X..
    .....
    X.@.X
    .....
    ..X..

hook weapons,

    X...X
    .....
    ..@..
    .....
    X...X

and reach weapons

    ...X...
    .......
    .......
    X..@..X
    .......
    .......
    ...X...

The longbow is special, threatening diagonal lines (after some distance) away from the wielding unit

    X.......X
    .X.....X.
    .........
    .........
    ....@....
    .........
    .........
    .X.....X.
    X.......X

Units, player and monster, are fragile. Any attack which rolls higher than a unit's relevant defense stat is fatal. The longbow, as well as any weapon that stacks two or more threat ranges, is a two handed weapon. Two handed weapons preclude the use of a shield, making a unit that much more fragile. My intent is the create combat that focuses on maneuvering and coordinating a squad of various weapon types, and where trapping enemy units is the primary challenge of killing them instead of relying entirely on more hit points and stronger attacks.

## Command Line Interface ##

Instead of key bindings, T31LoSB uses an in built command line for all player input; it's typo tolerant and has predictive text features!

### Battle Preparation Screen ###

Commands available when outfitting your squad:

    roster --to see the list of all your units
    inventory --to see a list of what item types exist and if you have items of any given type
    <item type> --to see all items of the given type
    ready --to start the next battle
    <unit name> stats
    <unit name> skills
    equip <unit name> <item name>
    unquip <unit name> <item name>

### Combat Screen ###

Commands available during a fight:

    move range <row column> --Shows on the map every square the unit at <row column> may move to. Think chess coordinates! <row column> is writ as aG with row in lowercase column in upper.
    threat range <row column> --Shows the melee range of the unit at <row column>.
    describe <tile name>
    describe <row column> --Shows the stats for the unit at <row column>
    directory --Brings up the list of all units and map feature. This list is open by default.
    <attacker row column> <victim row column> --Makes the unit at <attacker row column> attack the unit at <victim row column>
    <row column> <destination row column> --Move unit
    <spell name> <row column> <direction> --Every spell has a unique name. Direction is one of N, S, W, E, NW, NE, SW, or SE
